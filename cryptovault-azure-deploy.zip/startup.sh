#!/bin/bash
# Azure App Service startup script
echo "Starting CryptoVault Analytics on Azure..."
cd /home/site/wwwroot
export WEBSITES_PORT=5000
python -m pip install -r requirements.txt
gunicorn --bind=0.0.0.0:$WEBSITES_PORT app:app
